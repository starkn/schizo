#pragma once

#include <sstream>
#include <string>

using namespace std;

enum TokenType {
    COMMA, STRING, 
};

class Token {
    private:
    TokenType type;
    string value;
    int line;

    string typeName(TokenType type) const {
        switch (type) {
        case COMMA:
            return "COMMA";
        case STRING:
            return "STRING";
        }
        return "NULL";
    }

    public:
    Token(TokenType type, string value, int line)
     : type(type), value(value), line(line) { }

    string toString() {
        stringstream out;
        out << "(" << typeName(type) << "," << "\"" << value << "\"" << "," << line << ")";
        return out.str();
    }
};