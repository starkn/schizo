/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_147(unsigned *p)
{
    *p = 1483252337U;
}

unsigned addval_462(unsigned x)
{
    return x + 2462550344U;
}

unsigned addval_340(unsigned x)
{
    return x + 3281293400U;
}

unsigned addval_494(unsigned x)
{
    return x + 3284633928U;
}

void setval_325(unsigned *p)
{
    *p = 3243772779U;
}

unsigned addval_432(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_470(unsigned x)
{
    return x + 1486305034U;
}

unsigned getval_111()
{
    return 3284633864U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_477(unsigned x)
{
    return x + 3252717896U;
}

unsigned getval_176()
{
    return 3682914729U;
}

unsigned addval_345(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_232(unsigned x)
{
    return x + 3374370441U;
}

unsigned addval_334(unsigned x)
{
    return x + 3223900553U;
}

unsigned addval_398(unsigned x)
{
    return x + 3682128265U;
}

void setval_437(unsigned *p)
{
    *p = 3385118345U;
}

unsigned getval_117()
{
    return 3682910873U;
}

unsigned getval_144()
{
    return 3685008009U;
}

void setval_130(unsigned *p)
{
    *p = 2464188744U;
}

unsigned addval_152(unsigned x)
{
    return x + 3682914697U;
}

void setval_227(unsigned *p)
{
    *p = 2429455840U;
}

unsigned addval_212(unsigned x)
{
    return x + 3268512141U;
}

unsigned getval_361()
{
    return 2425409177U;
}

unsigned addval_138(unsigned x)
{
    return x + 3677933195U;
}

unsigned getval_139()
{
    return 3224949129U;
}

unsigned addval_165(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_343()
{
    return 2425409161U;
}

unsigned getval_238()
{
    return 3525362313U;
}

unsigned getval_298()
{
    return 3465384048U;
}

unsigned getval_421()
{
    return 3373843081U;
}

unsigned addval_167(unsigned x)
{
    return x + 3281044105U;
}

void setval_348(unsigned *p)
{
    *p = 3252717896U;
}

void setval_107(unsigned *p)
{
    *p = 3677929993U;
}

unsigned getval_249()
{
    return 3767094481U;
}

unsigned getval_497()
{
    return 3281175177U;
}

void setval_404(unsigned *p)
{
    *p = 3674788232U;
}

unsigned getval_222()
{
    return 2430634328U;
}

unsigned addval_188(unsigned x)
{
    return x + 2447411528U;
}

unsigned addval_268(unsigned x)
{
    return x + 3536110217U;
}

unsigned addval_422(unsigned x)
{
    return x + 3678981769U;
}

void setval_350(unsigned *p)
{
    *p = 3586314633U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
